////
// Enhanced Flag TImer is configured in two locations:
//   1) The in-game Options tab allows you to configure items that you might want to change on the fly: Flag Timer Start Values, Displayed In-match GUI Type(s)
//   2) This prefs file allows you to configure less commonly changed items: Flag Timer Text, and Styling, GUI variables.
////

// By default, Enhanced Flag Timer will support the exact same functionality as the legacy Flag Timer script (zFlagtimer.vl2). Specifically, it will
// display the time remaining until flag return in the Objective Hud. If you're using Enhanced Flag Timer, then it recommended that you remove
// the legacy Flag Timer script from your scripts folder so there is no conflict.
// However, if you want to continue using the legacy script, then simply set the variable below to true. By doing so, Enhanced Flag Timer will not change
// the text of the Objective Hud.
EnhancedFT.supportLegacyFlagTimerScript = false;

	// The text that is displayed before the flag timer value. Ex: "Friendly Flag Timer: 45s"
EnhancedFT.Friendly_Standard_Timer_Label = "Friendly Flag Timer:";
EnhancedFT.Friendly_Compact_Timer_Label = "FF:";
EnhancedFT.Enemy_Standard_Timer_Label = "Enemy Flag Timer:";
EnhancedFT.Enemy_Compact_Timer_Label = "EF:";

	// Flag timer text styling - standard GUI type
	// A9D7FA is an offwhite color used in T2's guiProfiles.cs for items like weapon ammo count.
EnhancedFT.Friendly_Standard_Font_Name = "Arial";
EnhancedFT.Friendly_Standard_Font_Size = "17";
EnhancedFT.Friendly_Standard_Font_Color = "A9D7FA"; 
EnhancedFT.Enemy_Standard_Font_Name = "Arial";
EnhancedFT.Enemy_Standard_Font_Size = "17";
EnhancedFT.Enemy_Standard_Font_Color = "A9D7FA";

	// Flag timer text styling - compact GUI type
	// A9D7FA is an offwhite color used in T2's guiProfiles.cs for items like weapon ammo count.
EnhancedFT.Friendly_Compact_Font_Name = "Univers";
EnhancedFT.Friendly_Compact_Font_Size = "15";
EnhancedFT.Friendly_Compact_Font_Color = "A9D7FA";
EnhancedFT.Enemy_Compact_Font_Name = "Univers";
EnhancedFT.Enemy_Compact_Font_Size = "15";
EnhancedFT.Enemy_Compact_Font_Color = "A9D7FA";

	// Flag timer GUI sizing / styling - standard GUI type
EnhancedFT.Standard_Timer_Width = 180;
EnhancedFT.Standard_Timer_Height = 25;

	// Flag timer GUI sizing / styling - compact GUI type
EnhancedFT.Compact_Timer_Width = 50;
EnhancedFT.Compact_Timer_Height = 21;