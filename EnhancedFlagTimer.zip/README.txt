////
//  Enhanced Flag Timer (EnhancedFT) was built to serve two purposes:
//    1) Provide a configurable Flag Timer GUI HUD that can be managed through HUD Mover. Runar released the original FlagTimer script in 2001 which displayed 
//       a flag timer in the objective HUD. Since that time, I'm unaware of any other script that tried to iterate this. His script was very simple, and 
//       it works fine. However, given how large our screens are now, having to look at small font in the bottom left of the screen for critcal information doesn't make sense.
//    2) Provide a way to customize the flag timer start value for a given CTF game mode. There is no mechanism by which the client can reference the configured flag 
//       return time from the server. In other words, whatever is configured by the server is hidden to the client. As a result, we have to configure it manually.
//       Runar's original script hard-coded a 45 second timer. Given the movement of the community to use a shorter timer for LCTF, this configuration now is necessary. 
// 
//   With the above, this script combines the following items:
//   - A complete redesign on how to manage flag timer data, making use of many of the new support /original classes. Almost nothing remains of the original Runar script.
//   - A configurable GUI for showing flag timer data in a large font or small font.
//   - A UI that allows you to configure the flag timer through the Lobby tab for the following modes: CTF, LCTF, Other (catch-all for other modes)
//   - A UI that allows you to configure flag timer values *per server* for a given game mode. This is useful when different servers us different flag timers
//   	for the same game mode.
//   - A mechanism for the script to detect the game mode dynamically.
//   - Playing a warning sound when the friendly flag is about to return. This is useful when the defense is guarding the flag in the field. It can get quite hectic,
//      and losing track of the return timer does occur.
////

Dependencies
You must ensure you support the following dependencies:
1. HudManager.vl2
2. UberGuy's Script Suite. 
   (I am unsure what supports this. This must include: a) Scripts tab in the browser, b) UberPrefs support. Both of the these are included in the all-in-one download.)

Instructions
1. Move EnhancedFT.vl2 to your z_scripts or scripts folder
2. Move prefs/EnhancedFlagTimerPrefs.cs to your base/prefs folder
3. Move audio/fx/misc/countdown_warning.wav to your audio/fx/misc folder
4. By default, this script also supports the old flag timer script behavior, where the flag timer is displayed in the Objective HUD. As a result, you should not needed
   to use these old scripts, and I would recommend removing them to avoid conflicts. The scripts names should either be: "zFlagTimer.vl2" or "FlagTimer.vl2".
   If you do want to continue using them, then there's a variable in the prefs file that will allow this. Simply set supportLegacyFlagTimerScript = true.
5. Most script configuration occurs in the UI via the Script tab in the browser. Simply find: "Enhanced Flag Timer". 
6. Additional GUI configuration can be performed in the provided EnhancedFlagTimerPrefs.cs file.
7. After loading a map, use HudMover to position the HUDs as desired: 
   - "Flag Timer Standard - Friendly"
   - "Flag Timer Standard - Enemy"
   - "Flag Timer Compact - Friendly"
   - "Flag Timer Compact - Enemy"
	

Known Issues
1. Timer info will not be initialized when a) a player joins a match, and b) a flag is dropped for a given team.
There is no possible way to handle this situation. The script is responsible for storing the time on which a flag is dropped. If the script has no knowledge of the drop time, 
then there is no way for it give accurate timer information.
 
Known Bugs
1. Does not work on Demo Playback
The script is dependent on callbacks from the support script, support/flag_tracker.cs. When playing demos, these
callbacks do not work. There is nothing that can be done to fix this, since flag_tracker.cs is a core
support script that cannot be edited by clients.